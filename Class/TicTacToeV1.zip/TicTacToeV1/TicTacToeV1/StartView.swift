//
//  ContentView.swift
//  TicTacToeV1
//
//  Created by Ittiyanam Tomichan on 2/19/24.
//

import SwiftUI

struct StartView: View {
    //lets create state properties to keep track of gametype, names of the users playing the game
    //
    @State private var gameType:GameType = .undetermined
    //technically self.undetermined
    @State private var yourName:String = "" //or u dont need string part
    @State private var opponentName:String = ""
    
    @FocusState private var focus:Bool
    //for the keyboard focus we want the keyboard to disappear when the game starts; set it to false in that case
    //this will be set to true when we are within the text view
    
    
    var body: some View {
        VStack {
            Picker("Select Game", selection: $gameType){
                Text("Select Game Type").tag(GameType.undetermined)
                Text("Share single device").tag(GameType.single)
                Text("Bot").tag(GameType.bot)
                Text("Multiplayer across devices").tag(GameType.peer)
                
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(style: StrokeStyle(lineWidth:2)))
            Text(gameType.description).padding()
            VStack{
                switch gameType {
                case .single:
                    TextField("Opponent Name", text:$opponentName)
                    
                case .bot:
                    TextField("Your Name", text:$yourName)
                case .peer:
                    EmptyView()
                case .undetermined:
                    EmptyView()
                }
                
            }.padding()
                .textFieldStyle(.roundedBorder)
                .focused($focus)
                .frame(width:350)
            
            if gameType != .peer{
                Button("Start Game"){
                    focus = false
                }
                .buttonStyle(.borderedProminent)
                .disabled(
                    gameType == .undetermined ||
                    gameType == .bot && yourName.isEmpty ||
                    gameType == .single && (yourName.isEmpty || opponentName.isEmpty)
                )
                Image("LaunchScreen")
            }
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            StartView()
        }
    }
}
