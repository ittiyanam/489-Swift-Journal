//
//  GameModels.swift
//  TicTacToeV1
//
//  Created by Ittiyanam Tomichan on 2/19/24.
//

import Foundation

enum GameType{
    case single, bot, peer, undetermined
    
    var description:String{
        switch self {
            //lowercase self is a current instance of the struct
            //uppercase self is the structure itseld
            case .single:
                return "Share ur device with ur friend and play with them"
            case .bot:
                return "Play against the device"
            case .peer:
                return "Invite someone near you with the app to play"
            case .undetermined:
                return ""
        }
    }
}

