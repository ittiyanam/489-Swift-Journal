//
//  TicTacToeV1App.swift
//  TicTacToeV1
//
//  Created by Ittiyanam Tomichan on 2/19/24.
//

import SwiftUI

@main
struct TicTacToeV1App: App {
    var body: some Scene {
        WindowGroup {
            StartView()
        }
    }
}
